<?php 
require __DIR__ . '/../../assets/import/PHPMailer/PHPMailerAutoload.php';
$mail = new PHPMailer;
?>