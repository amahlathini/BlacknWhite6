<?php

namespace Iyzipay;

interface RequestStringConvertible
{
    public function toPKIRequestString();
}