<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.deepsoundscript.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com
// +------------------------------------------------------------------------+
// | DeepSound - The Ultimate PHP Sound Sharing Platform
// | Copyright (c) 2019 DeepSound. All rights reserved.
// +------------------------------------------------------------------------+
// MySQL Hostname
$sql_db_host = "localhost";
// MySQL Database User
$sql_db_user = "blaceizz_blacknwhite6";
// MySQL Database Password
$sql_db_pass = "22cHain$";
// MySQL Database Name
$sql_db_name = "blaceizz_blacknwhite6";

// Site URL
$site_url = "https://blacknwhite6.com"; // e.g (http://example.com)

$developer_mode = 0;

// Purchase code
$purchase_code = "7bfb75ee-2409-47e9-8d59-118b39d9b0c6"; // Your purchase code, don't give it to anyone.
?>